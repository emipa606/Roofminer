# Roofminer

A mod for the game Rimworld. A new designator is provided for mining a
connected set of mountain tiles that share a roof type.

The primary purpose is to mine tunnels and rooms in mountains that won't trigger infestations.

Originally based on https://github.com/Ogliss/Veinminer-R1.0